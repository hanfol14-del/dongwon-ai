# Dongwon v2.0 — stable update signing

This build uses a stable signing key supplied through GitHub Actions Secrets so future APKs can update the installed app without uninstalling it.

Required GitHub Secrets:
- DONGWON_KEYSTORE_B64
- DONGWON_STORE_PASSWORD
- DONGWON_KEY_ALIAS
- DONGWON_KEY_PASSWORD

Never commit the keystore or passwords to the repository.
