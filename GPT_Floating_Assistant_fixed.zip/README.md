GPT 플로팅 비서 프로토타입
- 다른 앱 위에 작은 GPT 뱃지를 표시
- 탭하면 상태가 바뀜
- 다음 단계: 화면 캡처(MediaProjection), OpenAI API, OCR/번역, 접근성 기능
