# 동원이 v1.9

- v1.8.1 음성 호출/자동 음성모드 유지
- 기억 저장/검색 유지
- 위치 인식 유지
- 접근성 조작 강화 유지
- 화면 공유 안정화: MediaProjection foreground service type 지정
- Android 14+ MediaProjection callback 등록
- 화면 캡처 ImageReader 안정성 개선
- versionCode 14 / versionName 1.9

주의: GitHub Actions에서 매번 새 debug keystore가 만들어지면 APK 업데이트가 서명 불일치로 막힐 수 있습니다. 반복 업데이트를 하려면 한 번만 고정 서명키를 GitHub Secrets로 연결하세요.
