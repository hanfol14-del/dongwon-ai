package com.example.gptfloating

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.DatabaseUtils

class MemoryDb(context: Context) : SQLiteOpenHelper(context, "dongwon_memory.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE conversations (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_conversations_ts ON conversations(ts)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_conversations_role ON conversations(role)")
    }

    fun count(): Long = DatabaseUtils.queryNumEntries(readableDatabase, "conversations")

    fun add(role: String, text: String): Boolean {
        return try {
            val v = writableDatabase.insertOrThrow("conversations", null, android.content.ContentValues().apply {
                put("ts", System.currentTimeMillis()); put("role", role); put("text", text)
            })
            v != -1L
        } catch (_: Exception) { false }
    }

    fun recent(limit: Int = 30): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT role,text FROM conversations ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out.add((if (c.getString(0) == "user") "사용자" else "동원이") + ": " + c.getString(1))
        }
        return out.asReversed()
    }

    fun search(query: String, limit: Int = 12): List<String> {
        val terms = query.replace(Regex("[^가-힣A-Za-z0-9 ]"), " ").split(Regex("\\s+"))
            .filter { it.length >= 2 && it !in setOf("그때", "전에", "저번에", "그저번에", "그거", "그것", "뭐였지", "기억") }
        val rows = mutableListOf<Pair<Long, String>>()
        readableDatabase.rawQuery("SELECT id,role,text FROM conversations ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0); val role = c.getString(1); val text = c.getString(2)
                val score = if (terms.isEmpty()) 0 else terms.count { text.contains(it, true) }
                if (score > 0) rows.add(id to (if (role == "user") "사용자" else "동원이") + ": " + text)
            }
        }
        return if (terms.isEmpty()) recent(60).takeLast(limit) else rows.sortedByDescending { it.first }.take(limit).map { it.second }
    }
}
