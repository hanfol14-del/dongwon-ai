package com.example.gptfloating

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class DongwonAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: DongwonAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun snapshotText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb, 0)
        return sb.toString().take(8000)
    }

    private fun collect(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) sb.append(text).append(' ')
        else if (desc.isNotEmpty()) sb.append(desc).append(' ')
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, sb, depth + 1); it.recycle() }
    }

    fun clickText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findText(root, target) ?: return false
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        node.recycle(); return ok
    }

    private fun findText(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = node.text?.toString().orEmpty()
        val d = node.contentDescription?.toString().orEmpty()
        if (t.contains(target, true) || d.contains(target, true)) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findText(child, target)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    fun scrollForward(): Boolean = rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true
    fun scrollBackward(): Boolean = rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) == true
    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
