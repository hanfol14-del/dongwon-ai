package com.example.gptfloating

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class DongwonAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: DongwonAccessibilityService? = null }
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun snapshotText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb)
        return sb.toString().take(8000)
    }

    private fun collect(node: AccessibilityNodeInfo, sb: StringBuilder) {
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) sb.append(text).append(' ')
        else if (desc.isNotEmpty()) sb.append(desc).append(' ')
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child -> collect(child, sb); child.recycle() }
        }
    }

    fun clickText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findTextNode(root, target) ?: return false
        val ok = clickNodeOrAncestor(node)
        node.recycle()
        return ok
    }

    private fun clickNodeOrAncestor(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(node)
        try {
            for (depth in 0..6) {
                if (current == null) break
                if (current.isClickable && current.isEnabled) {
                    if (current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
                val parent = current.parent
                current.recycle()
                current = parent
            }
        } finally { current?.recycle() }

        val original = AccessibilityNodeInfo.obtain(node)
        return try {
            val bounds = Rect()
            original.getBoundsInScreen(bounds)
            if (bounds.isEmpty || bounds.width() < 2 || bounds.height() < 2) return false
            val x = bounds.centerX().toFloat()
            val y = bounds.centerY().toFloat()
            val path = Path().apply { moveTo(x, y); lineTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
                .build()
            dispatchGesture(gesture, null, null)
        } finally { original.recycle() }
    }

    private fun findTextNode(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val wanted = target.trim()
        val t = node.text?.toString().orEmpty()
        val d = node.contentDescription?.toString().orEmpty()
        if (wanted.isNotBlank() && (t.equals(wanted, true) || d.equals(wanted, true) ||
                    t.contains(wanted, true) || d.contains(wanted, true))) {
            return AccessibilityNodeInfo.obtain(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findTextNode(child, wanted)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    fun scrollForward(): Boolean = performScroll(true)
    fun scrollBackward(): Boolean = performScroll(false)

    private fun performScroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: root
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val ok = node.performAction(action)
        if (node !== root) node.recycle()
        return ok
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isEnabled) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
