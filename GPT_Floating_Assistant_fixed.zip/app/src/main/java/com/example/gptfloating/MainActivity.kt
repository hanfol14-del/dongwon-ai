package com.example.gptfloating

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.content.pm.PackageManager
import android.widget.*
import android.os.Build

class MainActivity : Activity() {
    companion object { const val REQUEST_CAPTURE = 7001 }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 60, 48, 40) }
        val t = TextView(this).apply { text = "동원이 ❤️\n\n화면 위에서 함께하는 AI 비서"; textSize = 22f }
        val start = Button(this).apply { text = "① 동원이 시작" }
        val settings = Button(this).apply { text = "② 동원이 설정" }
        box.addView(t); box.addView(start); box.addView(settings); setContentView(box)
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                if (Build.VERSION.SDK_INT >= 23) {
                    val needed = mutableListOf<String>()
                    if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(android.Manifest.permission.RECORD_AUDIO)
                    if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(android.Manifest.permission.POST_NOTIFICATIONS)
                    if (needed.isNotEmpty()) { requestPermissions(needed.toTypedArray(), 9102); return@setOnClickListener }
                }
                startService(Intent(this, FloatingService::class.java)); finish()
            }
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        settings.setOnClickListener { showSettings() }
    }

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("동원이 설정")
            .setItems(arrayOf("API 키 설정", "화면 공유 시작", "폰 조작 권한 설정", "음성 권한 설정", "위치 권한 설정", "동원이 권한 한눈에 보기")) { _, which ->
                when (which) {
                    0 -> askForApiKey()
                    1 -> requestScreenShare()
                    2 -> openAccessibilitySettings()
                    3 -> requestMicPermission()
                    4 -> requestLocationPermission()
                    5 -> showPermissionGuide()
                }
            }.show()
    }

    private fun askForApiKey() {
        val edit = EditText(this).apply {
            hint = "sk-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            isSingleLine = true
        }
        val paste = Button(this).apply {
            text = "클립보드에서 붙여넣기"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    edit.setText(clip.getItemAt(0).coerceToText(this@MainActivity))
                    edit.setSelection(edit.text.length)
                }
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 0, 40, 0)
            addView(edit, LinearLayout.LayoutParams(-1, 58)); addView(paste, LinearLayout.LayoutParams(-1, 58))
        }
        AlertDialog.Builder(this).setTitle("OpenAI API 키")
            .setMessage("API 키는 이 휴대폰에 저장돼. 키 자체를 다른 사람에게 보내지 마.")
            .setView(layout).setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ -> getSharedPreferences("dongwon", MODE_PRIVATE).edit().putString("api_key", edit.text.toString().trim()).apply() }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if ((requestCode == 9101 || requestCode == 9102) && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingService::class.java))
                finish()
            }
        }
    }

    private fun requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 9103)
    }

    private fun showPermissionGuide() {
        AlertDialog.Builder(this)
            .setTitle("동원이 권한 상태")
            .setMessage("""필수/권장 권한

• 다른 앱 위에 표시: 하트 뱃지
• 마이크: 음성 호출/대화
• 위치: 현재 위치/지역 인식
• 알림: 백그라운드 작업 결과
• 접근성: 홈/뒤로가기/클릭/스크롤
• 화면 공유: 현재 화면 분석

안드로이드가 보호하는 권한은 동원이가 몰래 가져갈 수 없고, 각 항목은 네가 직접 허용해야 해.""")
            .setPositiveButton("앱 권한 열기") { _, _ -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            .setNegativeButton("닫기", null).show()
    }

    private fun requestMicPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 9101)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestScreenShare() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, FloatingService::class.java).apply {
                action = "com.example.gptfloating.START_SCREEN_SHARE"
                putExtra("projection_data", data)
            }
            startForegroundService(serviceIntent)
        }
        finish()
    }
}
