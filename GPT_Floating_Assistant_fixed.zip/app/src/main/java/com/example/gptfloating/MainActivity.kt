package com.example.gptfloating

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    companion object { const val REQUEST_CAPTURE = 7001 }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 60, 48, 40) }
        val t = TextView(this).apply { text = "동원이 ❤️\n\n화면 위에서 함께하는 AI 비서"; textSize = 22f }
        val start = Button(this).apply { text = "① 동원이 시작" }
        val settings = Button(this).apply { text = "② 동원이 설정" }
        box.addView(t); box.addView(start); box.addView(settings); setContentView(box)
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) { startService(Intent(this, FloatingService::class.java)); finish() }
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        settings.setOnClickListener { showSettings() }
    }

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("동원이 설정")
            .setItems(arrayOf("API 키 설정", "화면 공유 시작")) { _, which ->
                if (which == 0) askForApiKey() else requestScreenShare()
            }.show()
    }

    private fun askForApiKey() {
        val edit = EditText(this).apply {
            hint = "sk-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            isSingleLine = true
        }
        val paste = Button(this).apply {
            text = "클립보드에서 붙여넣기"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    edit.setText(clip.getItemAt(0).coerceToText(this@MainActivity))
                    edit.setSelection(edit.text.length)
                }
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 0, 40, 0)
            addView(edit, LinearLayout.LayoutParams(-1, 58)); addView(paste, LinearLayout.LayoutParams(-1, 58))
        }
        AlertDialog.Builder(this).setTitle("OpenAI API 키")
            .setMessage("API 키는 이 휴대폰에 저장돼. 키 자체를 다른 사람에게 보내지 마.")
            .setView(layout).setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ -> getSharedPreferences("dongwon", MODE_PRIVATE).edit().putString("api_key", edit.text.toString().trim()).apply() }
            .show()
    }

    private fun requestScreenShare() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, FloatingService::class.java).apply {
                action = "com.example.gptfloating.START_SCREEN_SHARE"
                putExtra("projection_data", data)
            }
            startForegroundService(serviceIntent)
        }
        finish()
    }
}
