package com.example.gptfloating

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import kotlin.concurrent.thread

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var badge: View? = null
    private var chat: View? = null
    private var answerView: TextView? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var projectionThread: HandlerThread? = null
    @Volatile private var latestScreenJpeg: ByteArray? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBadge()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.example.gptfloating.START_SCREEN_SHARE") {
            val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("projection_data", Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra("projection_data")
            if (data != null) startScreenCapture(data)
        }
        return START_STICKY
    }

    private fun showBadge() {
        val b = HeartBadge(this).apply { setOnClickListener { toggleChat() } }
        badge = b
        val p = WindowManager.LayoutParams(86, 86, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 110
        p.y = 42
        wm.addView(b, p)
    }

    private fun toggleChat() {
        if (chat != null) { removeChat(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 14)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 28f; setStroke(2, Color.LTGRAY) }
        }
        val title = TextView(this).apply { text = "동원이 ❤️"; textSize = 19f; setTextColor(Color.DKGRAY) }
        val answer = TextView(this).apply { text = "사랑해 ❤️"; textSize = 16f; setPadding(0, 12, 0, 12) }
        val input = EditText(this).apply {
            hint = "동원에게 말해줘"
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            isFocusableInTouchMode = true
            setOnEditorActionListener { _, actionId, event ->
                val enterPressed = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND || enterPressed) {
                    sendPrompt(this, answer)
                    true
                } else false
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    postDelayed({
                        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                            .showSoftInput(this, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    }, 200)
                }
            }
        }
        answerView = answer
        box.addView(title)
        box.addView(answer)
        box.addView(input)
        chat = box
        val p = WindowManager.LayoutParams(760, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 80; p.y = 145
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
        wm.addView(box, p)
        input.requestFocus()
        input.postDelayed({
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 250)
    }

    private fun sendPrompt(input: EditText, answer: TextView) {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val apiKey = getSharedPreferences("dongwon", MODE_PRIVATE).getString("api_key", "") ?: ""
        if (apiKey.isBlank()) { answer.text = "먼저 앱에서 API 키를 설정해줘. ❤️"; return }
        answer.text = "생각 중이야…"
        input.text.clear()
        saveUserMessage(text)
        val memoryCommand = text.contains("기억") || text.contains("대화 기록") || text.contains("전에") || text.contains("저번") || text.contains("그저번")
        val wantsScreen = text.contains("화면") || text.contains("보고") || text.contains("보여") || text.contains("지금 뭐") || text.contains("뭐가 있어") || text.contains("뭐가 나와")
        val wantsWork = text.contains("해줘") || text.contains("해 줘") || text.contains("켜줘") || text.contains("꺼줘") || text.contains("눌러줘") || text.contains("눌러 줘") || text.contains("들어가줘") || text.contains("스크롤") || text.contains("뒤로 가") || text.contains("홈으로")
        thread {
            if (wantsWork) {
                callOpenAIForAction(apiKey, text, answer)
                return@thread
            }
            var screen = latestScreenJpeg
            if (wantsScreen) {
                var waited = 0
                while (screen == null && waited < 4000) { Thread.sleep(100); waited += 100; screen = latestScreenJpeg }
            }
            if (wantsScreen && screen != null) callOpenAIWithImage(apiKey, Base64.getEncoder().encodeToString(screen), text)
            else if (wantsScreen) runOnUiThread { answer.text = "아직 화면을 못 받았어. '화면 공유 시작'을 다시 눌러줘. ❤️" }
            else callOpenAI(apiKey, text, answer)
        }
    }

    private fun memoryContext(query: String): String {
        val db = MemoryDb(this)
        val q = query.lowercase()
        val vague = listOf("그때", "전에", "저번", "그저번", "그거", "그것", "기억나", "기억해").any { q.contains(it) }
        val found = if (vague) db.recent(200) else {
            val hits = db.search(query, 20)
            (db.recent(40) + hits).distinct().takeLast(80)
        }
        return found.joinToString("\n").take(16000)
    }

    private fun saveUserMessage(userText: String) {
        try { MemoryDb(this).add("user", userText) } catch (_: Exception) { }
    }

    private fun saveAssistantMessage(assistantText: String) {
        try { MemoryDb(this).add("assistant", assistantText) } catch (_: Exception) { }
    }

    private fun saveConversation(userText: String, assistantText: String) {
        saveUserMessage(userText); saveAssistantMessage(assistantText)
    }

    private fun requestScreenShare() {
        val i = Intent(this, MainActivity::class.java).apply {
            action = "com.example.gptfloating.REQUEST_SCREEN_SHARE"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(i)
    }

    private fun askForApiKey() {
        val edit = EditText(this).apply {
            hint = "sk-..."
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            isSingleLine = true
            isFocusableInTouchMode = true
        }
        val paste = Button(this).apply {
            text = "클립보드에서 붙여넣기"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    edit.setText(clip.getItemAt(0).coerceToText(this@FloatingService))
                    edit.setSelection(edit.text.length)
                }
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 0, 40, 0)
            addView(edit, LinearLayout.LayoutParams(-1, 58))
            addView(paste, LinearLayout.LayoutParams(-1, 58))
        }
        val dialog = AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert))
            .setTitle("OpenAI API 키")
            .setMessage("키는 이 휴대폰에만 저장돼. 공개 저장소에는 넣지 않아.")
            .setView(layout)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                getSharedPreferences("dongwon", MODE_PRIVATE).edit().putString("api_key", edit.text.toString().trim()).apply()
            }
            .create()
        dialog.setOnShowListener {
            edit.requestFocus()
            edit.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(edit, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }, 200)
        }
        dialog.show()
    }

    private fun callOpenAI(apiKey: String, prompt: String, answer: TextView) {
        try {
            val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Content-Type", "application/json")
            val memory = memoryContext(prompt)
            val body = JSONObject().apply {
                put("model", "gpt-5.6-luna")
                put("input", "너는 사용자의 휴대폰 비서 '동원이'야. 친근하고 짧게 한국어로 답해.\n이전 대화를 기억해서 자연스럽게 이어가. 모르는 내용은 기억하는 척하지 마.\n[이전 대화]\n$memory[현재 사용자 메시지]\n$prompt")
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val result = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(result)
            if (code !in 200..299) { runOnUiThread { answer.text = "API 오류($code)" }; conn.disconnect(); return }
            val text = json.optString("output_text").ifBlank { extractText(json) }
            if (text.isNotBlank()) saveAssistantMessage(text)
            runOnUiThread { answer.text = if (text.isBlank()) "응답을 읽지 못했어." else text }
            conn.disconnect()
        } catch (e: Exception) { runOnUiThread { answer.text = "연결에 실패했어. 인터넷과 API 키를 확인해줘." } }
    }

    private fun postActionNotification(title: String, text: String) {
        val channelId = "dongwon_actions"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "동원이 백그라운드 작업", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = Notification.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    private fun callOpenAIForAction(apiKey: String, userRequest: String, answer: TextView) {
        // UI를 붙잡지 않고 백그라운드에서 계획/실행한다. 실제 화면을 바꾸는 작업은
        // Android 접근성 서비스의 제약상 현재 전면 앱에 영향을 줄 수 있다.
        val accessibility = DongwonAccessibilityService.instance
        if (accessibility == null) {
            postActionNotification("동원이", "폰 조작 권한이 꺼져 있어. 접근성 권한을 켜줘.")
            runOnUiThread { answer.text = "백그라운드 작업을 준비했는데 접근성 권한이 필요해." }
            return
        }
        runOnUiThread {
            answer.text = "백그라운드에서 처리 중이야… ❤️"
            removeChat()
        }
        Thread {
            try {
                val ui = accessibility.snapshotText()
                val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"; conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $apiKey")
                conn.setRequestProperty("Content-Type", "application/json")
                val instructions = """
너는 휴대폰 비서 동원이야. 사용자의 요청을 보고 실제로 할 수 있는 작업을 하나 선택해 JSON 하나만 출력해.
허용 action: CLICK_TEXT, BACK, HOME, SCROLL_FORWARD, SCROLL_BACKWARD, NONE.
CLICK_TEXT일 때 target에는 현재 화면에 보이는 버튼/메뉴의 짧고 정확한 텍스트를 넣어.
안전하지 않거나 결제, 송금, 비밀번호, 인증번호, 금융거래, 삭제/초기화 등 민감한 작업은 NONE으로 답해.
화면을 실제로 바꿀 수 없는 요청도 NONE으로 답해.
형식: {"action":"CLICK_TEXT","target":"설정"}
""".trimIndent()
                val body = JSONObject().apply {
                    put("model", "gpt-5.6-luna")
                    put("input", instructions + "\n[현재 화면의 접근성 텍스트]\n" + ui + "\n[사용자 요청]\n" + userRequest)
                }.toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val result = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) {
                    postActionNotification("동원이 작업 실패", "API 오류($code)")
                    return@Thread
                }
                var raw = JSONObject(result).optString("output_text").ifBlank { extractText(JSONObject(result)) }.trim()
                raw = raw.removePrefix("```").removePrefix("json").removeSuffix("```").trim()
                val plan = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("action", "NONE") }
                val action = plan.optString("action", "NONE")
                val target = plan.optString("target", "")
                val ok = when (action) {
                    "CLICK_TEXT" -> target.isNotBlank() && accessibility.clickText(target)
                    "BACK" -> accessibility.goBack()
                    "HOME" -> accessibility.goHome()
                    "SCROLL_FORWARD" -> accessibility.scrollForward()
                    "SCROLL_BACKWARD" -> accessibility.scrollBackward()
                    else -> false
                }
                val response = when {
                    action == "NONE" -> "이 작업은 내가 안전하게 자동으로 할 수 없어. ❤️"
                    ok -> "백그라운드에서 처리했어. ❤️"
                    action == "CLICK_TEXT" -> "화면에서 '$target' 버튼을 찾지 못했어."
                    else -> "지금은 그 작업을 하지 못했어."
                }
                saveAssistantMessage(response)
                postActionNotification("동원이", response)
            } catch (_: Exception) {
                postActionNotification("동원이 작업 실패", "백그라운드 작업 중 오류가 났어.")
            }
        }.start()
    }

    private fun startScreenCapture(data: Intent) {
        try {
            createNotificationChannel()
            val notification = Notification.Builder(this, "dongwon_screen")
                .setContentTitle("동원이 화면 보기")
                .setContentText("화면을 동원이가 분석할 수 있도록 공유 중")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
            startForeground(101, notification)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(Activity.RESULT_OK, data)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            projectionThread = HandlerThread("DongwonScreen").also { it.start() }
            val handler = Handler(projectionThread!!.looper)
            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    buffer.rewind()
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    val cropped = if (bmp.width != width) Bitmap.createBitmap(bmp, 0, 0, width, height) else bmp
                    val out = ByteArrayOutputStream()
                    cropped.compress(Bitmap.CompressFormat.JPEG, 55, out)
                    latestScreenJpeg = out.toByteArray()
                    image.close(); if (cropped !== bmp) cropped.recycle(); bmp.recycle()
                } catch (_: Exception) { image.close() }
            }, handler)
            virtualDisplay = projection!!.createVirtualDisplay("DongwonScreen", width, height, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader!!.surface, null, handler)
        } catch (_: Exception) { runOnUiThread { answerView?.text = "화면 공유를 시작하지 못했어." } }
    }

    private fun callOpenAIWithImage(apiKey: String, base64: String, userRequest: String) {
        try {
            val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $apiKey"); conn.setRequestProperty("Content-Type", "application/json")
            val memory = memoryContext(userRequest)
            val content = JSONArray().apply {
                put(JSONObject().apply { put("type", "input_text"); put("text", "너는 사용자의 휴대폰 비서 '동원이'야. 이전 대화를 기억해서 자연스럽게 이어가.\n[이전 대화]\n$memory\n사용자가 이렇게 요청했어: $userRequest\n현재 휴대폰 화면을 보고 요청에 맞게 짧고 정확하게 답해줘.") })
                put(JSONObject().apply { put("type", "input_image"); put("image_url", "data:image/jpeg;base64,$base64"); put("detail", "low") })
            }
            val input = JSONArray().put(JSONObject().apply { put("role", "user"); put("content", content) })
            val body = JSONObject().apply { put("model", "gpt-5.6-luna"); put("input", input) }.toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val result = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
            val json = JSONObject(result)
            val text = json.optString("output_text").ifBlank { extractText(json) }
            if (text.isNotBlank()) saveAssistantMessage(text)
            runOnUiThread { answerView?.text = if (text.isBlank()) "화면은 봤는데 설명을 읽지 못했어." else text }
            conn.disconnect()
        } catch (_: Exception) { runOnUiThread { answerView?.text = "화면 분석에 실패했어." } }
    }

    private fun extractText(json: JSONObject): String {
        val out = json.optJSONArray("output") ?: return ""
        for (i in 0 until out.length()) { val item = out.optJSONObject(i) ?: continue; val content = item.optJSONArray("content") ?: continue; for (j in 0 until content.length()) { val c = content.optJSONObject(j) ?: continue; val t = c.optString("text"); if (t.isNotBlank()) return t } }
        return ""
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("dongwon_screen", "동원이 화면 공유", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun runOnUiThread(r: () -> Unit) { Handler(mainLooper).post { r() } }
    private fun removeChat() { chat?.let { wm.removeView(it) }; chat = null }

    override fun onDestroy() {
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projection?.stop(); projection = null
        projectionThread?.quitSafely(); projectionThread = null
        latestScreenJpeg = null
        removeChat(); badge?.let { wm.removeView(it) }; badge = null; super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null

    class HeartBadge(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val path = Path()
            path.moveTo(w/2, h*0.88f); path.cubicTo(w*0.05f,h*0.55f,w*0.05f,h*0.18f,w*0.28f,h*0.16f); path.cubicTo(w*0.42f,h*0.14f,w*0.5f,h*0.27f,w*0.5f,h*0.27f); path.cubicTo(w*0.5f,h*0.27f,w*0.58f,h*0.14f,w*0.72f,h*0.16f); path.cubicTo(w*0.95f,h*0.18f,w*0.95f,h*0.55f,w/2,h*0.88f)
            paint.color = Color.rgb(225,35,60); c.drawPath(path,paint); paint.color=Color.WHITE; paint.textAlign=Paint.Align.CENTER; paint.textSize=22f; paint.typeface=Typeface.DEFAULT_BOLD; c.drawText("동원",w/2,h*0.55f,paint)
        }
    }
}
