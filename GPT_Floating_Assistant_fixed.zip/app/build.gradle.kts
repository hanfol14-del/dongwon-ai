plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gptfloating"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.gptfloating"
        minSdk = 26
        targetSdk = 35
        versionCode = 15
        versionName = "2.0"
    }
    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("DONGWON_KEYSTORE_PATH")
            val storePassword = System.getenv("DONGWON_STORE_PASSWORD")
            val keyAlias = System.getenv("DONGWON_KEY_ALIAS")
            val keyPassword = System.getenv("DONGWON_KEY_PASSWORD")
            if (!keystorePath.isNullOrBlank() && !storePassword.isNullOrBlank() && !keyAlias.isNullOrBlank() && !keyPassword.isNullOrBlank()) {
                storeFile = file(keystorePath)
                this.storePassword = storePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}
