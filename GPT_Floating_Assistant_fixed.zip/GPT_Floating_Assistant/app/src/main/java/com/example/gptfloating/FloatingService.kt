package com.example.gptfloating

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var badge: View? = null
    private var chat: View? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBadge()
    }

    private fun showBadge() {
        val b = HeartBadge(this).apply { setOnClickListener { toggleChat() } }
        badge = b
        val p = WindowManager.LayoutParams(86, 86, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 12
        p.y = 36
        wm.addView(b, p)
    }

    private fun toggleChat() {
        if (chat != null) { removeChat(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 14)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 28f; setStroke(2, Color.LTGRAY) }
        }
        val title = TextView(this).apply { text = "동원이  ❤️"; textSize = 19f; setTextColor(Color.DKGRAY) }
        val answer = TextView(this).apply { text = "안녕! 이제 내가 여기 들어왔어.\n뭐 도와줄까?"; textSize = 16f; setPadding(0, 12, 0, 12) }
        val input = EditText(this).apply { hint = "동원이에게 말해줘"; singleLine = false; maxLines = 3 }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val key = Button(this).apply { text = "API키" }
        val send = Button(this).apply { text = "보내기" }
        row.addView(key, LinearLayout.LayoutParams(0, 52, 1f)); row.addView(send, LinearLayout.LayoutParams(0, 52, 1f))
        box.addView(title); box.addView(answer); box.addView(input); box.addView(row)
        key.setOnClickListener { askForApiKey() }
        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            val apiKey = getSharedPreferences("dongwon", MODE_PRIVATE).getString("api_key", "") ?: ""
            if (apiKey.isBlank()) { askForApiKey(); return@setOnClickListener }
            answer.text = "생각 중이야…"
            thread { callOpenAI(apiKey, text, answer) }
        }
        chat = box
        val p = WindowManager.LayoutParams(760, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 18; p.y = 135
        wm.addView(box, p)
    }

    private fun askForApiKey() {
        val edit = EditText(this).apply { hint = "sk-..."; inputType = 129 }
        AlertDialog.Builder(android.view.ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert))
            .setTitle("OpenAI API 키")
            .setMessage("키는 이 휴대폰에만 저장돼. 공개 저장소에는 넣지 않아.")
            .setView(edit)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                getSharedPreferences("dongwon", MODE_PRIVATE).edit().putString("api_key", edit.text.toString().trim()).apply()
            }.show()
    }

    private fun callOpenAI(apiKey: String, prompt: String, answer: TextView) {
        try {
            val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().apply {
                put("model", "gpt-5.6-luna")
                put("input", "너는 사용자의 휴대폰 비서 '동원이'야. 친근하고 짧게 한국어로 답해.\n사용자: $prompt")
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val result = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(result)
            val text = json.optString("output_text").ifBlank { extractText(json) }
            runOnUiThread { answer.text = if (text.isBlank()) "응답을 읽지 못했어. API 키와 네트워크를 확인해줘." else text }
            conn.disconnect()
        } catch (e: Exception) {
            runOnUiThread { answer.text = "연결에 실패했어. 인터넷과 API 키를 확인해줘." }
        }
    }

    private fun extractText(json: JSONObject): String {
        val out = json.optJSONArray("output") ?: return ""
        for (i in 0 until out.length()) {
            val item = out.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text")
                if (t.isNotBlank()) return t
            }
        }
        return ""
    }

    private fun runOnUiThread(r: () -> Unit) { android.os.Handler(mainLooper).post(r) }

    private fun removeChat() { chat?.let { wm.removeView(it) }; chat = null }

    override fun onDestroy() { removeChat(); badge?.let { wm.removeView(it) }; badge = null; super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null

    class HeartBadge(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            val path = Path()
            path.moveTo(w/2, h*0.88f)
            path.cubicTo(w*0.05f, h*0.55f, w*0.05f, h*0.18f, w*0.28f, h*0.16f)
            path.cubicTo(w*0.42f, h*0.14f, w*0.5f, h*0.27f, w*0.5f, h*0.27f)
            path.cubicTo(w*0.5f, h*0.27f, w*0.58f, h*0.14f, w*0.72f, h*0.16f)
            path.cubicTo(w*0.95f, h*0.18f, w*0.95f, h*0.55f, w/2, h*0.88f)
            paint.color = Color.rgb(225, 35, 60); c.drawPath(path, paint)
            paint.color = Color.WHITE; paint.textAlign = Paint.Align.CENTER; paint.textSize = 22f; paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("동원", w/2, h*0.55f, paint)
        }
    }
}
