package com.example.gptfloating

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    companion object { const val REQUEST_CAPTURE = 7001 }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 60, 48, 40) }
        val t = TextView(this).apply { text = "동원이 ❤️\n\n화면 위에서 함께하는 AI 비서"; textSize = 22f }
        val p = Button(this).apply { text = "① 다른 앱 위에 표시 권한" }
        val s = Button(this).apply { text = "② 동원 띄우기" }
        box.addView(t); box.addView(p); box.addView(s); setContentView(box)
        p.setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        s.setOnClickListener {
            if (Settings.canDrawOverlays(this)) { startService(Intent(this, FloatingService::class.java)); finish() } else p.performClick()
        }
        if (intent?.action == "com.example.gptfloating.REQUEST_SCREEN_SHARE") { requestScreenShare() }
    }

    private fun requestScreenShare() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, FloatingService::class.java).apply {
                action = "com.example.gptfloating.START_SCREEN_SHARE"
                putExtra("projection_data", data)
            }
            startForegroundService(serviceIntent)
        }
        finish()
    }
}
