package com.example.gptfloating
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
class MainActivity: Activity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b)
  val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(48,60,48,40)
  val t=TextView(this); t.text="GPT 플로팅 비서\n\n화면 한쪽에 뱃지를 띄우는 프로토타입"; t.textSize=22f
  val p=Button(this); p.text="① 다른 앱 위에 표시 권한"
  val s=Button(this); s.text="② GPT 뱃지 띄우기"
  box.addView(t); box.addView(p); box.addView(s); setContentView(box)
  p.setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
  s.setOnClickListener { if(Settings.canDrawOverlays(this)) startService(Intent(this,FloatingService::class.java)) else p.performClick() }
 }
}
